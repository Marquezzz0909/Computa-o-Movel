package EXER_1

fun main() {
    val squares1 = IntArray(50) { (it + 1) * (it + 1) }
    println("Quadrados perfeitos usando IntArray: ${squares1.joinToString()}")

    val squares2 = (1..50).map { it * it }
    println("Quadrados perfeitos usando map(): ${squares2.joinToString()}")

    val squares3 = Array(50) { (it + 1) * (it + 1) }
    println("Quadrados perfeitos usando Array: ${squares3.joinToString()}")
}