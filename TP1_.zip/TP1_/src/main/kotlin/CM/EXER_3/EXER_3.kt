package CM.EXER_3

fun main() {
    val heights = generateSequence(100.0) { it * 0.6 }
        .takeWhile { it >= 1.0 }
        .take(15)
        .toList()

    heights.forEach { println(String.format("%.2f", it)) }
}
