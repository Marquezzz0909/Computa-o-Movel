package EXER_2

fun main() {
    println("Digite a operação (ex: 2 + 3):")
    val input = readLine()!!
    val parts = input.split(" ")

    val num1 = parts[0].toInt()
    val operator = parts[1]
    val num2 = parts[2].toInt()

    when (operator) {
        "+" -> println("Resultado: ${num1 + num2}")
        "-" -> println("Resultado: ${num1 - num2}")
        "*" -> println("Resultado: ${num1 * num2}")
        "/" -> {
            if (num2 != 0) {
                println("Resultado: ${num1 / num2}")
            } else {
                println("Erro: Divisão por zero.")
            }
        }
        "&&" -> println("Resultado: ${num1 != 0 && num2 != 0}")
        "||" -> println("Resultado: ${num1 != 0 || num2 != 0}")
        "shl" -> println("Resultado: ${num1 shl num2}")
        else -> println("Operação inválida.")
    }
}