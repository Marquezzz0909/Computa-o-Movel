package com.a15053.coolweatherapp


data class WeatherData(
    var latitude: String,
    var longitude: String,
    var timezone: String,
    var current_weather: CurrentWeather,
    var hourly: Hourly
)

data class CurrentWeather(
    var temperature: Float,
    var windspeed: Float,
    var winddirection: Int,
    var weathercode: Int,
    var time: String
)

data class Hourly(
    var time: ArrayList<String>,
    var temperature_2m: ArrayList<Float>,
    var weathercode: ArrayList<Int>,
    var pressure_msl: ArrayList<Float>
)

enum class WMO_WeatherCode(var code: Int, var image: String) {
    CLEAR_SKY(0, "clear"),
    MAINLY_CLEAR(1, "mostly_clear"),
    PARTLY_CLOUDY(2, "partly_cloudy"),
    OVERCAST(3, "cloudy"),
    FOG(45, "fog"),
    DRIZZLE_LIGHT(51, "drizzle"),
    RAIN_SLIGHT(61, "rain_light"),
    RAIN_MODERATE(63, "rain"),
    RAIN_HEAVY(65, "rain_heavy"),
    SNOW_FALL_SLIGHT(71, "snow_light"),
    SNOW_FALL_MODERATE(73, "snow"),
    SNOW_FALL_HEAVY(75, "snow_heavy"),
    THUNDERSTORM(95, "tstorm")
}

fun getWeatherCodeMap(): Map<Int, WMO_WeatherCode> {
    val weatherMap = HashMap<Int, WMO_WeatherCode>()

    WMO_WeatherCode.values().forEach {
        weatherMap.put(it.code, it)
    }

    return weatherMap
}