package cm.ex1

sealed class Event {
    abstract val username: String
    abstract val timestamp: Long

    data class Login(
        override val username: String,
        override val timestamp: Long
    ) : Event()

    data class Purchase(
        override val username: String,
        val amount: Double,
        override val timestamp: Long
    ) : Event()

    data class Logout(
        override val username: String,
        override val timestamp: Long
    ) : Event()
}

fun List<Event>.filterByUser(username: String): List<Event> {
    return filter { it.username == username }
}

fun List<Event>.totalSpent(username: String): Double {
    return filterIsInstance<Event.Purchase>()
        .filter { it.username == username }
        .sumOf { it.amount }
}

fun processEvents(events: List<Event>, handler: (Event) -> Unit) {
    events.forEach(handler)
}

fun main() {
    val events = listOf(
        Event.Login("alice", 1000),
        Event.Purchase("alice", 49.99, 1100),
        Event.Purchase("bob", 19.99, 1200),
        Event.Login("bob", 1050),
        Event.Purchase("alice", 15.0, 1300),
        Event.Logout("alice", 1400),
        Event.Logout("bob", 1500)
    )

    processEvents(events) { event ->
        when (event) {
            is Event.Login ->
                println("[LOGIN]    ${event.username} logged in at t=${event.timestamp}")

            is Event.Purchase ->
                println("[PURCHASE] ${event.username} spent ${event.amount} at t=${event.timestamp}")

            is Event.Logout ->
                println("[LOGOUT]   ${event.username} logged out at t=${event.timestamp}")
        }
    }

    println()
    println("Total spent by alice: \$${events.totalSpent("alice")}")
    println("Total spent by bob: \$${events.totalSpent("bob")}")

    println()
    println("Events for alice:")
    events.filterByUser("alice").forEach { println(it) }
}