package cm.ex2

class Cache<K : Any, V : Any> {
    private val data = mutableMapOf<K, V>()

    fun put(key: K, value: V) {
        data[key] = value
    }

    fun get(key: K): V? {
        return data[key]
    }

    fun evict(key: K) {
        data.remove(key)
    }

    fun size(): Int {
        return data.size
    }

    fun getOrPut(key: K, default: () -> V): V {
        val value = data[key]
        if (value != null) {
            return value
        }

        val newValue = default()
        data[key] = newValue
        return newValue
    }

    fun transform(key: K, action: (V) -> V): Boolean {
        val currentValue = data[key] ?: return false
        data[key] = action(currentValue)
        return true
    }

    fun snapshot(): Map<K, V> {
        return data.toMap()
    }

    fun filterValues(predicate: (V) -> Boolean): Map<K, V> {
        return data.filterValues(predicate).toMap()
    }
}

fun main() {
    val wordCache = Cache<String, Int>()

    wordCache.put("kotlin", 1)
    wordCache.put("scala", 1)
    wordCache.put("haskell", 1)

    println("--- Word frequency cache ---")
    println("Size: ${wordCache.size()}")
    println("Frequency of \"kotlin\": ${wordCache.get("kotlin")}")
    println("getOrPut \"kotlin\": ${wordCache.getOrPut("kotlin") { 0 }}")
    println("getOrPut \"java\": ${wordCache.getOrPut("java") { 0 }}")
    println("Size after getOrPut: ${wordCache.size()}")
    println("Transform \"kotlin\" (+1): ${wordCache.transform("kotlin") { it + 1 }}")
    println("Transform \"cobol\" (+1): ${wordCache.transform("cobol") { it + 1 }}")
    println("Snapshot: ${wordCache.snapshot()}")

    println()
    println("Filtered values (> 0): ${wordCache.filterValues { it > 0 }}")

    println()
    println("--- ID registry cache ---")
    val idCache = Cache<Int, String>()

    idCache.put(1, "Alice")
    idCache.put(2, "Bob")

    println("Id 1 -> ${idCache.get(1)}")
    println("Id 2 -> ${idCache.get(2)}")

    idCache.evict(1)
    println("After evict id 1, size: ${idCache.size()}")
    println("Id 1 after evict -> ${idCache.get(1)}")
}