package cm.ex3

class Pipeline {
    private val stages = mutableListOf<Pair<String, (List<String>) -> List<String>>>()

    fun addStage(name: String, transform: (List<String>) -> List<String>) {
        stages.add(name to transform)
    }

    fun execute(input: List<String>): List<String> {
        var result = input

        for (stage in stages) {
            result = stage.second(result)
        }

        return result
    }

    fun describe() {
        println("Pipeline stages:")
        for (i in stages.indices) {
            println("${i + 1}. ${stages[i].first}")
        }
    }

    fun compose(newName: String, firstStageName: String, secondStageName: String): Boolean {
        val first = stages.find { it.first == firstStageName }?.second ?: return false
        val second = stages.find { it.first == secondStageName }?.second ?: return false

        addStage(newName) { input ->
            second(first(input))
        }

        return true
    }
}

fun buildPipeline(block: Pipeline.() -> Unit): Pipeline {
    val pipeline = Pipeline()
    pipeline.block()
    return pipeline
}

fun fork(input: List<String>, p1: Pipeline, p2: Pipeline): Pair<List<String>, List<String>> {
    return Pair(p1.execute(input), p2.execute(input))
}

fun main() {
    val logs = listOf(
        "  INFO: server started  ",
        "  ERROR: disk full  ",
        "  DEBUG: checking config  ",
        "  ERROR: out of memory  ",
        "  INFO: request received  ",
        "  ERROR: connection timeout  "
    )

    val pipeline = buildPipeline {
        addStage("Trim") { lines ->
            lines.map { it.trim() }
        }

        addStage("Filter errors") { lines ->
            lines.filter { it.contains("ERROR") }
        }

        addStage("Uppercase") { lines ->
            lines.map { it.uppercase() }
        }

        addStage("Add index") { lines ->
            lines.mapIndexed { index, line -> "${index + 1}. $line" }
        }
    }

    pipeline.describe()

    println()
    println("Result:")
    val result = pipeline.execute(logs)
    result.forEach { println(it) }
}